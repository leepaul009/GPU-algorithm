#ifndef LIBSVM_PREDICT
#define LIBSVM_PREDICT
namespace svmpredict {
	int main(int argc, char **argv);
}
#endif
