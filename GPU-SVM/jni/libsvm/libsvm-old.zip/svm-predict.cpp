#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>


#include <string.h>
#include <errno.h>
#include "../common.h"
#include "svm-predict.h"
#include "svm.h"

#include <fstream>
#include <stdarg.h>
#include <string>
#include <assert.h>
#include <math.h>
#include <time.h>
#include <malloc.h>
#include <vector>

#include <cstring>
#include <sstream>
#include <iostream>
#include <fstream> // std::ifstream
#include <cstdio>
#include <cstdlib>
#include <iterator>

/******************* opencl ******************/
#ifdef _MOBILE
#include <CL/cl.h>
#else
#include <CL/opencl.h>
#endif

#define MAX_SOURCE_SIZE (0x100000)

namespace svmpredict {
	int print_null(const char *s,...) {return 0;}

	struct svm_node *x;
	int max_nr_attr = 64;

	struct svm_model* model;
	int predict_probability=0;

	static char *line = NULL;
	static int max_line_len;

	static char* readline(FILE *input)
	{
		int len;

		if(fgets(line,max_line_len,input) == NULL)
			return NULL;

		while(strrchr(line,'\n') == NULL)
		{
			max_line_len *= 2;
			line = (char *) realloc(line,max_line_len);
			len = (int) strlen(line);
			if(fgets(line+len,max_line_len-len,input) == NULL)
				break;
		}
		return line;
	}

	void exit_input_error(int line_num)
	{
		debug("Wrong input format at line %d\n", line_num);
		exit(1);
	}

	void predict(FILE *input, FILE *output)
	{
		int correct = 0;
		int total = 0;
		double error = 0;
		double sump = 0, sumt = 0, sumpp = 0, sumtt = 0, sumpt = 0;

		int svm_type=svm_get_svm_type(model);
		int nr_class=svm_get_nr_class(model);
		double *prob_estimates=NULL;
		int j;

		if(predict_probability)
		{
			if (svm_type==NU_SVR || svm_type==EPSILON_SVR)
				debug("Prob. model for test data: target value = predicted value + z,\nz: Laplace distribution e^(-|z|/sigma)/(2sigma),sigma=%g\n",svm_get_svr_probability(model));
			else
			{
				int *labels=(int *) malloc(nr_class*sizeof(int));
				svm_get_labels(model,labels);
				prob_estimates = (double *) malloc(nr_class*sizeof(double));
				fprintf(output,"labels");		
				for(j=0;j<nr_class;j++)
					fprintf(output," %d",labels[j]);
				fprintf(output,"\n");
				free(labels);
			}
		}

		max_line_len = 1024;
		line = (char *)malloc(max_line_len*sizeof(char));
#ifdef P_PARALLEL
/******************* OPENCL initiation start ******************/
		cl_device_id* Devices;
		cl_platform_id* Platforms;
		cl_uint NbPlatforms, NbDevices; // platform id
		cl_context Context;
		cl_command_queue CommandQueue;
		cl_kernel ckMatrix;
		cl_int status;
		cl_program Program;
		/*** get platforms ***/
		status = clGetPlatformIDs(0, NULL, &NbPlatforms);
		Platforms = (cl_platform_id*) malloc( NbPlatforms*sizeof(cl_platform_id) );
		status = clGetPlatformIDs(NbPlatforms, Platforms, NULL);

		char clinfo[1000];
		status = clGetPlatformInfo(Platforms[0], CL_PLATFORM_NAME, sizeof(clinfo), clinfo, NULL);
		debug("%s\n", clinfo);
		/*** get devices ***/
		status = clGetDeviceIDs(Platforms[0], CL_DEVICE_TYPE_GPU, 0, NULL, &NbDevices);
		Devices = (cl_device_id*) malloc( NbDevices*sizeof(cl_device_id) );
		status = clGetDeviceIDs(Platforms[0], CL_DEVICE_TYPE_GPU, NbDevices, Devices, NULL);

		status = clGetDeviceInfo(Devices[0], CL_DEVICE_NAME, sizeof(clinfo), clinfo, NULL);
		debug("%s\n", clinfo);

		Context = clCreateContext(0, 1, &Devices[0], NULL, NULL, &status);
		CommandQueue = clCreateCommandQueue(Context, Devices[0], CL_QUEUE_PROFILING_ENABLE, &status);
		debug("OpenCL initialization OK !\n");

/*
		size_t kernel_code_size;
		char *kernel_src_str;
		kernel_src_str = (char *)malloc(MAX_SOURCE_SIZE);
		FILE *kernelFile;
		kernelFile = fopen("/storage/sdcard0/libsvm/myCLMatrix.cl", "r");
		//kernelFile = fopen("myCLMatrix.cl", "r");
		kernel_code_size = fread(kernel_src_str, 1, MAX_SOURCE_SIZE, kernelFile);
		fclose(kernelFile);
		debug("read cl ok !\n");
		Program = clCreateProgramWithSource(Context, 1, (const char **)&kernel_src_str, (const size_t *)&kernel_code_size, &status);
*/

		/*** write Program ***/
		std::string fileDir;
#ifdef _MOBILE
		fileDir.append("/storage/sdcard0/libsvm/myCLMatrix.cl");
#else
		fileDir.append("myCLMatrix.cl");
#endif
		std::string kernelSource = loadProgram(fileDir);
		const char* kernelSourceChar = kernelSource.c_str();

		/*** create Program ***/
		Program = clCreateProgramWithSource(Context, 1, &kernelSourceChar, NULL, &status);
		if(status != CL_SUCCESS) debug("clCreateProgramWithSource failed!\n");
		status = clBuildProgram(Program, 0, NULL, NULL, NULL, NULL);
		if(status != CL_SUCCESS) debug("clBuildProgram failed!\n");

		/*** create Kernel ***/
		ckMatrix = clCreateKernel(Program, "myMatrixComputation", &status);
		if(status != CL_SUCCESS) debug("clCreateKernel failed!\n");
		debug("clCreateKernel OK!\n");
/******************* OPENCL initiation end ******************/

		int ir, jr;
		int nFeats=198;
		int l = model->l;
		model->h_sv = (float *)malloc(l*nFeats*sizeof(float));
		for(ir=0; ir<l; ir++)
		{
			jr=0;
			svm_node *y = model->SV[ir];
			while(y->index !=-1)
			{
				model->h_sv[jr*l+ir] = (float)y->value;
				++jr;
				++y;
			}
		}
		model->d_A = clCreateBuffer(Context, CL_MEM_READ_WRITE, l*nFeats*sizeof(float), NULL, &status);
		if(status != CL_SUCCESS) debug("model->d_A failed to create!\n");
		status = clEnqueueWriteBuffer(CommandQueue, model->d_A, CL_TRUE, 0, l*nFeats*sizeof(float), model->h_sv, 0, NULL, NULL);
		if(status != CL_SUCCESS) debug("model->d_A failed to write!\n");

#endif
		while(readline(input) != NULL)
		{
			int i = 0;
			double target_label, predict_label;
			char *idx, *val, *label, *endptr;
			int inst_max_index = -1; // strtol gives 0 if wrong format, and precomputed kernel has <index> start from 0

			label = strtok(line," \t\n");
			if(label == NULL) exit_input_error(total+1);// empty line

			target_label = strtod(label,&endptr);
			if(endptr == label || *endptr != '\0') exit_input_error(total+1);

			while(1)
			{
				if(i>=max_nr_attr-1)	// need one more for index = -1
				{
					max_nr_attr *= 2;
					x = (struct svm_node *) realloc(x,max_nr_attr*sizeof(struct svm_node));
				}

				idx = strtok(NULL,":");
				val = strtok(NULL," \t");

				if(val == NULL) break;
				errno = 0;

				int tmpIndex = (int) strtol(idx,&endptr,10);

				if(endptr == idx || errno != 0 || *endptr != '\0' || tmpIndex <= inst_max_index) exit_input_error(total+1);
				else inst_max_index = tmpIndex; //x[i].index;

				errno = 0;

				double tmpValue = strtod(val,&endptr);
				int tmpii = 0;

				if( (i+1) == tmpIndex )
				{
					x[i].index = tmpIndex;
					x[i].value = tmpValue;
				}
				else if( (i+1) < tmpIndex )
				{
					tmpii = tmpIndex - (i + 1); // =1,2...
					for(int irr=0; irr<tmpii; irr++)
					{
						x[i].index = i+1;
						x[i].value = 0.0;
						++i;
					}
					x[i].index = tmpIndex;
					x[i].value = tmpValue;
				}
				if(endptr == val || errno != 0 || (*endptr != '\0' && !isspace(*endptr))) exit_input_error(total+1);
				++i;
			}
			x[i].index = -1;
			if (predict_probability && (svm_type==C_SVC || svm_type==NU_SVC))
			{
				predict_label = svm_predict_probability(model,x,prob_estimates);
				fprintf(output,"%g",predict_label);
				for(j=0;j<nr_class;j++) fprintf(output," %g",prob_estimates[j]);
				fprintf(output,"\n");
			}
			else
			{
				//predict_label = svm_predict2(model, x, Context, CommandQueue, ckMatrix);
				predict_label = svm_predict(model, x);
				fprintf(output,"%g\n",predict_label);
			}

			if(predict_label == target_label) ++correct;
			error += (predict_label-target_label)*(predict_label-target_label);
			sump += predict_label;
			sumt += target_label;
			sumpp += predict_label*predict_label;
			sumtt += target_label*target_label;
			sumpt += predict_label*target_label;
			++total;
		}
#ifdef P_PARALLEL
		clReleaseMemObject(model->d_A);
		clReleaseKernel(ckMatrix);
		clReleaseProgram(Program);
		clReleaseCommandQueue(CommandQueue);
		clReleaseContext(Context);
#endif

		if (svm_type==NU_SVR || svm_type==EPSILON_SVR)
		{
			debug("Mean squared error = %g (regression)\n",error/total);
			debug("Squared correlation coefficient = %g (regression)\n",
				((total*sumpt-sump*sumt)*(total*sumpt-sump*sumt))/
				((total*sumpp-sump*sump)*(total*sumtt-sumt*sumt))
				);
		}
		else
			debug("Accuracy = %g%% (%d/%d) (classification)\n",
				(double)correct/total*100,correct,total);
		if(predict_probability) free(prob_estimates);
	}

	void exit_with_help()
	{
		debug(
		"Usage: svm-predict [options] test_file model_file output_file\n"
		"options:\n"
		"-b probability_estimates: whether to predict probability estimates, 0 or 1 (default 0); for one-class SVM only 0 is supported\n"
		"-q : quiet mode (no outputs)\n"
		);
		exit(1);
	}

	int main(int argc, char **argv)
	{
		FILE *input, *output;
		int i;
		// parse options
		for(i=1;i<argc;i++)
		{
			if(argv[i][0] != '-') break;
			++i;
			switch(argv[i-1][1])
			{
				case 'b':
					predict_probability = atoi(argv[i]);
					break;
				case 'q':
					//info = &print_null;
					i--;
					break;
				default:
					debug("Unknown option: -%c\n", argv[i-1][1]);
					exit_with_help();
			}
		}

		if(i>=argc-2)
			exit_with_help();

		input = fopen(argv[i],"r");
		if(input == NULL)
		{
			debug("can't open input file %s\n",argv[i]);
			exit(1);
		}

		output = fopen(argv[i+2],"w");
		if(output == NULL)
		{
			debug("can't open output file %s\n",argv[i+2]);
			exit(1);
		}

		if((model=svm_load_model(argv[i+1]))==0)
		{
			debug("can't open model file %s\n",argv[i+1]);
			exit(1);
		}

		x = (struct svm_node *) malloc(max_nr_attr*sizeof(struct svm_node));
		if(predict_probability)
		{
			if(svm_check_probability_model(model)==0)
			{
				debug("Model does not support probabiliy estimates\n");
				exit(1);
			}
		}
		else
		{
			if(svm_check_probability_model(model)!=0)
				debug("Model supports probability estimates, but disabled in prediction.\n");
		}

		predict(input,output);
		svm_free_and_destroy_model(&model);
		free(x);
		free(line);
		fclose(input);
		fclose(output);
		return 0;
	}
}
