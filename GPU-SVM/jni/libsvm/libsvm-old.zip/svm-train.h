#ifndef LIBSVM_TRAIN
#define LIBSVM_TRAIN
namespace svmtrain {
	int main(int argc, char **argv);
}
#endif
