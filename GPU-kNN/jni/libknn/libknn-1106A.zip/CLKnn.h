// parallel-knn, 2016/11/03A
#pragma once

#define _MOBILE 1
//#define USE_KERNEL_PREDICT 1
//#define _FPRINTF 1
#include "../common.h"

#ifdef _MOBILE
#include <CL/cl.h>
#else
#define CL_USE_DEPRECATED_OPENCL_2_0_APIS
#include <CL/opencl.h>
#endif


/****************************************************/
using namespace std;

#define MAX_BUFFER 2048
//#define NUM_FEATS 199
//#define NUM_TEST  6900
//#define NUM_TRAIN 27000
#define NUM_KNN_K 16 //大于4的整数,4的倍数
#define WRAP 64
#define SPLIT 64
#define _BITS 5
#define _RADIX (1 << _BITS)
#define _PASS 7
#define _CLASS 9
#define _MULTIPLY 64
#define _KSPLIT 8
#define MAX_SOURCE_SIZE (0x100000)
#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned short htype;

class CLKnn
{
	public:
		CLKnn(cl_context Context, cl_device_id Device, cl_command_queue CommandQueue);
		~CLKnn();

		void init_variable_from_prob(const char *filename, uint *input_size, int lmt);
		//lmt can effect input_size
		void read_problem(const char *filename, float *h_input, uint input_size, int cha);
		void PreProcess(void);
		void CLDistance(void);
		void Sort();
		void Histogram(uint pass);
		void ScanHistogram();
		void Reorder(uint pass);
		void Predict(uint idx);
		void calcuPrediction(uint idx, float threshold);
		void PrintPrediction(const char *filename);

		cl_context Context;
		cl_device_id Device;
		cl_command_queue CommandQueue;
		cl_program Program;

		int nFeats;
		int split; // the number of splits in one training line
		int radix;
		int radixbits;
		int kSplit;
		int kValue;
		int nClass;


		uint nTests;
		uint nTrains;
		uint nTests_rounded;
		uint nTests_inWork;
		uint nTrains_rounded;

		float *h_Test;
		float *h_Train;
		//ushort *predict_list;

		htype *h_ClassHist;

		cl_mem d_test;
		cl_mem d_train;
		cl_mem d_inDist; //float
		cl_mem d_inLabel; //uchar
		cl_mem d_outDist; //float
		cl_mem d_outLabel; //uchar
		cl_mem d_Histograms; //uint
		cl_mem d_globsum;
		cl_mem d_gsum;
		cl_mem d_ClassHist; //histogram of class
		cl_mem d_ClassTable;

		cl_ulong localMem;// for checking of local memory size

		cl_kernel ckDist;
		cl_kernel ckHistogram;  // compute histograms
		cl_kernel ckScanHistogram; // scan local histogram
		cl_kernel ckScanHistogram2;
		cl_kernel ckPasteHistogram; // paste local histograms
		cl_kernel ckReorder; // final reordering
		cl_kernel ckClassifyHist;
		cl_kernel ckClassifyTable;

		int true_predict_num;
		int num_after_reject;
		float predictive_rate;

		//int nnsvm_true_predict_num;

		int TP[_CLASS]; // true positive
		int FP[_CLASS]; // false positive
		int FN[_CLASS]; // false negative
		int TN[_CLASS]; // true negative
		int P[_CLASS];
		int R[_CLASS];


		long exetime;
		uint64_t uT;
		//float dist_time, histo_time, scan_time, reorder_time, sort_time, predict_time;
};


