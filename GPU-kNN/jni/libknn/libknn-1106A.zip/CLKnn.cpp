// parallel-knn, 2016/11/03A
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include <assert.h>
#include <time.h>
#include <math.h>
#include <string.h>

#include <string>
#include <fstream>
#include <iostream>
#include <iterator>

/*
#include <ctype.h>
#include <float.h>
#include <limits.h>
#include <locale.h>
*/
#include "CLKnn.h"

__inline__ std::string loadProgram2(std::string input)
{
	std::ifstream stream(input.c_str());
	if (!stream.is_open()) {
		printf("Cannot open input file\n");
		exit(1);
	}
	return std::string( std::istreambuf_iterator<char>(stream), (std::istreambuf_iterator<char>()));
}

__inline__ long getTimeNsec()
{
	struct timespec now;
	clock_gettime(CLOCK_MONOTONIC, &now);
	return (long) now.tv_sec*1000000000LL + now.tv_nsec;
}


using namespace std;

static char *line = NULL;
static int max_line_len;
static char* readline(FILE *input)
{
	int len;
	if(fgets(line,max_line_len,input) == NULL) return NULL;
	while(strrchr(line,'\n') == NULL)
	{
		max_line_len *= 2;
		line = (char *) realloc(line,max_line_len);
		len = (int) strlen(line);
		if(fgets(line+len,max_line_len-len,input) == NULL)
			break;
	}
	return line;
}


CLKnn::CLKnn(cl_context GPUContext, cl_device_id dev, cl_command_queue CommandQue):
	Context(GPUContext), Device(dev), CommandQueue(CommandQue)
{
/*** get input data ***/
#ifdef _MOBILE
	char input_train_file_name[1024] = "/storage/sdcard0/libsvm/b9f3t.scale";
	char input_test_file_name[1024] = "/storage/sdcard0/libsvm/b9f3p.scale";
	char predict_result_file_name[1024] = "/storage/sdcard0/libsvm/predict_result.csv";
#else
	char input_train_file_name[1024] = "../0.data/data/b9f3t.s";
	char input_test_file_name[1024] = "../0.data/data/b9f3p.s";
	char predict_result_file_name[1024] = "result/predict_result.csv";
#endif
	//同时,为h_Train初始化,为nFeats,h_Train和nTests赋值
	init_variable_from_prob(input_train_file_name, &nTrains, 0); //0:lmt
	init_variable_from_prob(input_test_file_name, &nTests, 0);

	cl_int err;
	d_train	= clCreateBuffer(Context, CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, sizeof(float)*nTrains*nFeats, NULL, &err);
	if(err != CL_SUCCESS) debug("d_train failed to create!\n");
	h_Train = (float*)clEnqueueMapBuffer(CommandQueue, d_train, CL_TRUE, CL_MAP_WRITE, 0, sizeof(float)*nTrains*nFeats, 0, NULL, NULL, &err);
	if(err != CL_SUCCESS) debug("Cannot map from d_train to h_train");

	h_Test = new float[nTests*nFeats];

	read_problem(input_train_file_name, h_Train, nTrains, 1); //1:reverse storage
	read_problem(input_test_file_name, h_Test, nTests, 0);


	/*** init host data ***/
	split = SPLIT;
	radix = _RADIX;
	radixbits = _BITS;
	kValue = NUM_KNN_K;
	kSplit = NUM_KNN_K/4; //表示 kernel class_hist 的线程数目
	nClass = _CLASS;
	kValue = (int)ceil((float)kValue / (float)kSplit)*kSplit;
	nTrains_rounded = ((uint)ceil((double)nTrains / (double)_MULTIPLY))*_MULTIPLY;
	nTests_inWork = 1; //满足 nTests_inWork*split 是WRAP的复数
	h_ClassHist = new htype[nTests_inWork*kSplit*nClass];

	//if(nTests_inWork*split < WRAP) debug("nTests_inWork*split is smaller than WRAP");
	//保证histogram function的线程数 大于 可操作的数据块
	clGetDeviceInfo(dev, CL_DEVICE_LOCAL_MEM_SIZE, sizeof(localMem), &localMem, NULL);
	debug("Testing data has %d rows, and training data after width-fixing has %d rows", nTests, nTrains_rounded);

	/*** create kernel and MEM object ***/
	PreProcess();
	err = clEnqueueUnmapMemObject(CommandQueue, d_train, h_Train, 0, NULL, NULL);
	if(err != CL_SUCCESS) debug("d_train failed to unmap!\n");

	/*** initiate evaluation factor ***/
	true_predict_num = 0;
	num_after_reject = 0;
	for(int i=0; i<nClass; i++)
	{
		TP[i] = 0; FP[i] = 0; FN[i] = 0; TN[i] = 0; P[i] = 0; R[i] = 0;
	}

	/*** get executing time ***/
	exetime = getTimeNsec();

	for(uint i=0; i<nTests/nTests_inWork; i++)
	{
		debug("%d",i);
		int h_class[nClass];
		err = clEnqueueWriteBuffer(CommandQueue, d_test, CL_TRUE, 0, sizeof(float)*nTests_inWork*nFeats, &h_Test[i*nTests_inWork*nFeats], 0, NULL, NULL);
		if(err != CL_SUCCESS) debug("Can not write buffer of d_test\n");
		CLDistance();
		Sort();
		//Predict(i);

		uchar *h_inLabel = (uchar*)clEnqueueMapBuffer(CommandQueue, d_inLabel, CL_TRUE, CL_MAP_READ, 0,
											 sizeof(uchar)*nTests_inWork*nTrains_rounded, 0, NULL, NULL, &err);
		if(err != CL_SUCCESS) debug("Cannot map from d_inLabel to h_inLabel");

		for(int ix=0; ix<nClass; ix++) h_class[ix] = 0;
		for(int ix=0; ix<kValue; ix++) ++h_class[ h_inLabel[ix] ];

		err = clEnqueueUnmapMemObject(CommandQueue, d_inLabel, h_inLabel, 0, NULL, NULL);
		if(err != CL_SUCCESS) debug("d_inLabel failed to unmap!\n");


		//err = clEnqueueReadBuffer(CommandQueue, d_ClassHist, CL_TRUE, 0, sizeof(htype)*nTests_inWork*kSplit*nClass, h_ClassHist, 0, NULL, NULL);
		//if(err != CL_SUCCESS) debug("Can not read buffer of d_ClassHist\n");
		//calcuPrediction(i, 0.0);

		int true_label = 0;
		int predict_label = 0;
		int big_val = h_class[predict_label];
		for(int j=1; j<nClass; j++)
			if(big_val < h_class[j])
			{
				predict_label = j;
				big_val = h_class[j];
			}
		true_label = (int)h_Test[ i*nTests_inWork*nFeats + nFeats-1 ] - 1;
		if(true_label == predict_label) true_predict_num++;
		num_after_reject++;


	}
	exetime = getTimeNsec() - exetime;

	//PrintPrediction(predict_result_file_name);
	debug("well predicted number: %d, overall accuracy: %f", true_predict_num, (float)true_predict_num/(float)num_after_reject);
	debug("final computing time is %ld", exetime);
}

CLKnn::~CLKnn()
{
	delete[] h_Test;
	//delete[] h_Train;
	delete[] h_ClassHist;

	clReleaseMemObject(d_test);
	clReleaseMemObject(d_train);

	clReleaseMemObject(d_inDist);
	clReleaseMemObject(d_inLabel);
	clReleaseMemObject(d_outDist);
	clReleaseMemObject(d_outLabel);

	clReleaseMemObject(d_Histograms);
	clReleaseMemObject(d_globsum);
	clReleaseMemObject(d_gsum);

	clReleaseKernel(ckDist);
	clReleaseKernel(ckHistogram);
	clReleaseKernel(ckScanHistogram);
	clReleaseKernel(ckScanHistogram2);
	clReleaseKernel(ckPasteHistogram);
	clReleaseKernel(ckReorder);

	clReleaseProgram(Program);
	clReleaseCommandQueue(CommandQueue);
	clReleaseContext(Context);
}

void CLKnn::PreProcess(void)
{
	cl_int err;
	/*** create program with source & build program ***/
    debug("create program with source");
    string fileDir;
#ifdef _MOBILE
    fileDir.append("/storage/sdcard0/libsvm/kernel_pknn.cl");
#else
    fileDir.append("CLKnn.cl");
#endif
    string kernelSource = loadProgram2(fileDir);
    const char* kernelSourceChar = kernelSource.c_str();
    debug("create program with source!");
	Program = clCreateProgramWithSource(Context, 1, &kernelSourceChar, NULL, &err);
	err = clBuildProgram(Program, 0, NULL, NULL, NULL, NULL);
	if(err != CL_SUCCESS)debug("create program failed\n");

	/*** create kernel ***/
	debug("create kernel...");
	ckDist 				= clCreateKernel(Program, "Dist", &err);
	ckHistogram 		= clCreateKernel(Program, "histogram", &err);
	ckScanHistogram 	= clCreateKernel(Program, "scanhistograms", &err);
	ckScanHistogram2 	= clCreateKernel(Program, "scanhistograms2", &err);
	ckPasteHistogram 	= clCreateKernel(Program, "pastehistograms", &err);
	ckReorder 			= clCreateKernel(Program, "reorder", &err);
	ckClassifyHist 		= clCreateKernel(Program, "class_histogram", &err);

	/*** create device buffer ***/
	debug("create buffer...");
	//d_train		= clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(float)*nTrains*nFeats, NULL, &err);
	//d_train		= clCreateBuffer(Context, CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, sizeof(float)*nTrains*nFeats, NULL, &err);
	//if(err != CL_SUCCESS) debug("d_A failed to create!\n");

	d_test		= clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(float)*nTests_inWork*nFeats, NULL, &err);

	d_inDist 	= clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(float)*nTests_inWork*nTrains_rounded, NULL, &err);
	d_inLabel 	= clCreateBuffer(Context, CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR, sizeof(uchar)*nTests_inWork*nTrains_rounded, NULL, &err);
	d_outDist 	= clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(float)*nTests_inWork*nTrains_rounded, NULL, &err);
	d_outLabel 	= clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(uchar)*nTests_inWork*nTrains_rounded, NULL, &err);

	d_Histograms = clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(htype)*nTests_inWork*split*radix, NULL, &err);
	d_globsum 	= clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(htype)*nTests_inWork*radix, NULL, &err);
	d_gsum 		= clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(htype)*nTests_inWork, NULL, &err);
	d_ClassHist = clCreateBuffer(Context, CL_MEM_READ_WRITE, sizeof(htype)*nTests_inWork*kSplit*nClass, NULL, &err);
}

void CLKnn::CLDistance(void)
{
	cl_int err;
	cl_event eve;
	size_t globalSize = nTests_inWork*nTrains_rounded;
	size_t localSize = WRAP;

	err = clSetKernelArg(ckDist, 0, sizeof(cl_mem), &d_test);
	err = clSetKernelArg(ckDist, 1, sizeof(cl_mem), &d_train);
	err = clSetKernelArg(ckDist, 2, sizeof(cl_mem), &d_inDist);
	err = clSetKernelArg(ckDist, 3, sizeof(cl_mem), &d_inLabel);
	err = clSetKernelArg(ckDist, 4, sizeof(uint), &nTests_inWork); //参加此次运算的test数据
	err = clSetKernelArg(ckDist, 5, sizeof(uint), &nTrains_rounded);
	err = clSetKernelArg(ckDist, 6, sizeof(uint), &nTrains);
	err = clSetKernelArg(ckDist, 7, sizeof(uint), &nFeats);
	if(err != CL_SUCCESS) debug("Cannot set kernel arg of CLDistance\n");

	err = clEnqueueNDRangeKernel(CommandQueue, ckDist, 1, NULL, &globalSize, &localSize, 0, NULL, &eve);
	if(err != CL_SUCCESS) debug("Cannot run kernel ckDist\n");
	clFinish(CommandQueue);
/*
	cl_ulong debut, fin;
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_QUEUED, sizeof(cl_ulong), (void*)&debut, NULL);
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), (void*)&fin, NULL);
	assert(err == CL_SUCCESS);
	dist_time += (float)(fin - debut) / 1e9;*/
}

void CLKnn::Sort()
{
	for(uint pass=0; pass<_PASS; pass++){
		Histogram(pass);
		ScanHistogram();
		Reorder(pass);
	}
}

void CLKnn::Histogram(uint pass)
{
	cl_int err;
	cl_event eve;
	size_t globalSize = nTests_inWork*split;
	size_t localSize = WRAP;

	err = clSetKernelArg(ckHistogram, 0, sizeof(cl_mem), &d_inDist);
	err = clSetKernelArg(ckHistogram, 1, sizeof(htype)*localSize*radix, NULL); //4096byte
	err = clSetKernelArg(ckHistogram, 2, sizeof(uint), &pass);
	err = clSetKernelArg(ckHistogram, 3, sizeof(cl_mem), &d_Histograms);
	err = clSetKernelArg(ckHistogram, 4, sizeof(uint), &radixbits);
	err = clSetKernelArg(ckHistogram, 5, sizeof(uint), &nTrains_rounded);
	err = clSetKernelArg(ckHistogram, 6, sizeof(uint), &split);
	err = clSetKernelArg(ckHistogram, 7, sizeof(uint), &radix);
	if(err != CL_SUCCESS) debug("cannot set kernel arg of Histogram\n");
	if(sizeof(htype)*localSize*radix >= localMem) debug("local memory is not enough for Histogram\n");

	err = clEnqueueNDRangeKernel(CommandQueue, ckHistogram, 1, NULL, &globalSize, &localSize, 0, NULL, &eve);
	if(err != CL_SUCCESS) debug("Cannot run kernel ckHistogram\n");
	clFinish(CommandQueue);

/*	cl_ulong debut, fin;
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_QUEUED, sizeof(cl_ulong), (void*)&debut, NULL);
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), (void*)&fin, NULL);
	assert(err == CL_SUCCESS);
	histo_time += (float)(fin - debut) / 1e9;*/
}

void CLKnn::ScanHistogram(void)
{
	/**********************  1th scan histogram  **********************/
	cl_int err;
	cl_event eve;
	size_t globalSize = nTests_inWork*radix;
	size_t localSize = radix;

	err = clSetKernelArg(ckScanHistogram, 0, sizeof(cl_mem), &d_Histograms);
	err = clSetKernelArg(ckScanHistogram, 1, sizeof(htype)*radix*split, NULL); //4096byte
	err = clSetKernelArg(ckScanHistogram, 2, sizeof(cl_mem), &d_globsum);
	err = clSetKernelArg(ckScanHistogram, 3, sizeof(uint), &split);
	if(err != CL_SUCCESS) debug("cannot set kernel arg of ScanHistogram1\n");
	if(sizeof(htype)*radix*split >= localMem) debug("local memory is not enough for ScanHistogram1\n");

	err = clEnqueueNDRangeKernel(CommandQueue, ckScanHistogram, 1, NULL, &globalSize, &localSize, 0, NULL, &eve);
	if(err != CL_SUCCESS) debug("Cannot run kernel ckScanHistogram1\n");
	clFinish(CommandQueue);
/*
	cl_ulong debut, fin;
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_QUEUED, sizeof(cl_ulong), (void*)&debut, NULL);
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), (void*)&fin, NULL);
	assert(err == CL_SUCCESS);
	scan_time += (float)(fin - debut) / 1e9;
*/
	/**********************  2th scan histogram  *********************/
	localSize = radix/2; //16
	globalSize = nTests_inWork*localSize;

	err = clSetKernelArg(ckScanHistogram2, 0, sizeof(cl_mem), &d_globsum);
	err = clSetKernelArg(ckScanHistogram2, 1, sizeof(htype)*radix, NULL);
	err = clSetKernelArg(ckScanHistogram2, 2, sizeof(cl_mem), &d_gsum);
	if(err != CL_SUCCESS) debug("Cannot set kernel arg of ckScanHistogram2\n");
	if(sizeof(htype)*radix >= localMem) debug("local memory is not enough for ScanHistogram2\n");

	err = clEnqueueNDRangeKernel(CommandQueue, ckScanHistogram2, 1, NULL, &globalSize, &localSize, 0, NULL, &eve);
	if(err != CL_SUCCESS) debug("Cannot run kernel ckScanHistogram2\n");
	clFinish(CommandQueue);
/*
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_QUEUED, sizeof(cl_ulong), (void*)&debut, NULL);
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), (void*)&fin, NULL);
	assert(err == CL_SUCCESS);
	scan_time += (float)(fin - debut) / 1e9;
*/
	/**********************  paste histogram  **********************/
	globalSize = nTests_inWork*radix;
	localSize = radix;

	err = clSetKernelArg(ckPasteHistogram, 0, sizeof(cl_mem), &d_Histograms);
	err = clSetKernelArg(ckPasteHistogram, 1, sizeof(cl_mem), &d_globsum);
	err = clSetKernelArg(ckPasteHistogram, 2, sizeof(uint), &split);
	if(err != CL_SUCCESS) debug("Cannot set kernel arg of ckPasteHistogram\n");

	err = clEnqueueNDRangeKernel(CommandQueue, ckPasteHistogram, 1, NULL, &globalSize, &localSize, 0, NULL, &eve);
	if(err != CL_SUCCESS) debug("Cannot run kernel ckPasteHistogram\n");
	clFinish(CommandQueue);
/*
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_QUEUED, sizeof(cl_ulong), (void*)&debut, NULL);
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), (void*)&fin, NULL);
	assert(err == CL_SUCCESS);
	scan_time += (float)(fin - debut) / 1e9;*/
}

void CLKnn::Reorder(uint pass)
{
	cl_int err;
	cl_event eve;
	size_t globalSize = nTests_inWork*split;
	size_t localSize = WRAP;

	err = clSetKernelArg(ckReorder, 0, sizeof(cl_mem), &d_inDist);
	err = clSetKernelArg(ckReorder, 1, sizeof(cl_mem), &d_inLabel);
	err = clSetKernelArg(ckReorder, 2, sizeof(cl_mem), &d_outDist);
	err = clSetKernelArg(ckReorder, 3, sizeof(cl_mem), &d_outLabel);
	err = clSetKernelArg(ckReorder, 4, sizeof(cl_mem), &d_Histograms);
	err = clSetKernelArg(ckReorder, 5, sizeof(htype)*localSize *radix, NULL);
	err = clSetKernelArg(ckReorder, 6, sizeof(uint), &pass);
	err = clSetKernelArg(ckReorder, 7, sizeof(uint), &split);
	err = clSetKernelArg(ckReorder, 8, sizeof(uint), &nTrains_rounded);
	err = clSetKernelArg(ckReorder, 9, sizeof(uint), &radixbits);
	err = clSetKernelArg(ckReorder, 10, sizeof(uint), &radix);

	if(err != CL_SUCCESS) debug("Cannot set kernel arg of ckReorder\n");
	assert(sizeof(htype)*localSize*radix < localMem);

	err = clEnqueueNDRangeKernel(CommandQueue, ckReorder, 1, NULL, &globalSize, &localSize, 0, NULL, &eve);
	if(err != CL_SUCCESS) debug("Cannot run kernel ckReorder\n");
	clFinish(CommandQueue);
/*
	cl_ulong debut, fin;
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_QUEUED, sizeof(cl_ulong), (void*)&debut, NULL);
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), (void*)&fin, NULL);
	assert(err == CL_SUCCESS);
	reorder_time += (float)(fin - debut) / 1e9;
*/
	cl_mem d_temp;
	d_temp = d_inDist;
	d_inDist = d_outDist;
	d_outDist = d_temp;

	d_temp = d_inLabel;
	d_inLabel = d_outLabel;
	d_outLabel = d_temp;
}

void CLKnn::Predict(uint idx)
{
	cl_int err;
	cl_event eve;

	err = clSetKernelArg(ckClassifyHist, 0, sizeof(cl_mem), &d_inLabel);
	err = clSetKernelArg(ckClassifyHist, 1, sizeof(cl_mem), &d_ClassHist);
	err = clSetKernelArg(ckClassifyHist, 2, sizeof(uint), &kValue);
	err = clSetKernelArg(ckClassifyHist, 3, sizeof(uint), &nClass);
	err = clSetKernelArg(ckClassifyHist, 4, sizeof(uint), &kSplit);
	err = clSetKernelArg(ckClassifyHist, 5, sizeof(uint), &nTrains_rounded);
	if(err != CL_SUCCESS) debug("Cannot set kernel arg of ckClassifyHist\n");

	size_t globalSize = nTests_inWork * kSplit;
	size_t localSize = kSplit;

	err = clEnqueueNDRangeKernel(CommandQueue, ckClassifyHist, 1, NULL, &globalSize, &localSize, 0, NULL, &eve);
	if(err != CL_SUCCESS) debug("Cannot run kernel ckClassifyHist\n");
	clFinish(CommandQueue);
/*
	cl_ulong debut, fin;
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_QUEUED, sizeof(cl_ulong), (void*)&debut, NULL);
	err = clGetEventProfilingInfo(eve, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), (void*)&fin, NULL);
	assert(err == CL_SUCCESS);
	predict_time += (float)(fin - debut) / 1e9;
*/
}

void CLKnn::calcuPrediction(uint idx, float threshold)
{
	//float predictive_rate;
	for(uint i=0; i<nTests_inWork; i++)
	{
		int h_class[nClass];
		for(int j=0; j<nClass; j++) h_class[j] = 0;
		for(int j=0; j<kSplit; j++)
			for(int ir=0; ir<nClass; ir++)
				h_class[ir] += h_ClassHist[i*kSplit*nClass + j*nClass + ir];

		int true_label = 0;
		int predict_label = 0;
		int big_val = h_class[predict_label];
		for(int j=1; j<nClass; j++)
			if(big_val < h_class[j])
			{
				predict_label = j;
				big_val = h_class[j];
			}

		predictive_rate = (float)big_val/(float)kValue;
		if(predictive_rate > threshold)
		{
			true_label = (int)h_Test[ idx*nTests_inWork*nFeats + i*nTests_inWork*nFeats + nFeats-1 ] - 1;
			for(int idx=0; idx<nClass; idx++)
			{
				if(true_label == idx) 		R[idx]++; //FN+TP
				if(predict_label == idx) 	P[idx]++; //TP+FP
				if((predict_label == idx) && (true_label == predict_label)) TP[idx]++;
			}
			if(true_label == predict_label) true_predict_num++;
			num_after_reject++;
		}
	}//end for loop
}

void CLKnn::PrintPrediction(const char *filename)
{
	float rate;
	rate = (float)true_predict_num/(float)num_after_reject;
#ifdef _FPRINTF
	FILE *fp;
	fp = fopen(filename,"wt");
	for(int l=0; l<nClass; l++)
	{
		FN[l] = R[l] - TP[l];
		FP[l] = P[l] - TP[l];
		TN[l] = num_after_reject - FN[l] - TP[l] - FP[l];
	}

	fprintf(fp,"class idx, accuracy, specificity, precision, recall\n");
	for(int l=0; l<nClass; l++)
	{
		fprintf(fp,"%d,",l+1);
		fprintf(fp,"%f,", (float)(TP[l] + TN[l])/(float)(TP[l] + TN[l] + FP[l] + FN[l]) );//accuracy
		fprintf(fp,"%f,", (float)TN[l]/(float)(TN[l] + FP[l]) );//specificity
		fprintf(fp,"%f,", (float)TP[l]/(float)(TP[l] + FP[l]) );//precision
		fprintf(fp,"%f\n", (float)TP[l]/(float)(TP[l] + FN[l]) );//recall
	}

	fprintf(fp,"well predicted number, number after rejection, number before rejection, overall accuracy\n");
	fprintf(fp,"%d,",true_predict_num);
	fprintf(fp,"%d,",num_after_reject);
	fprintf(fp,"%d,",nTests);
	fprintf(fp,"%f,",rate);
	fclose(fp);
#endif
	debug("well predicted number: %d, overall accuracy: %f\n", true_predict_num, rate);
}

void CLKnn::init_variable_from_prob(const char *filename, uint *input_size, int lmt)
{
	FILE *fp;
	fp = fopen(filename,"r");
	max_line_len = MAX_BUFFER;
	line = Malloc(char,max_line_len);
	ushort tmp_width;
	ushort width =0;
	int prob_len = 0;

	while(readline(fp)!=NULL)
	{
		char *p = strtok(line," \t");
		tmp_width = 0;
		while(1)
		{
			p = strtok(NULL," \t");
			if(p == NULL || *p == '\n')break;
			++tmp_width;
		}
		if(width < tmp_width) width = tmp_width;
		++prob_len;
	}
	if(lmt!=0)
	{
		if(prob_len < lmt){
			debug("length erro\n");
			return;
		}else{
			prob_len = lmt;
		}
	}
	*input_size = prob_len;
	nFeats = width;

	fclose(fp);
	free(line);
	debug("problem length: %d, feature number: %d", prob_len, nFeats);
}

void CLKnn::read_problem(const char *filename, float *h_input, uint prob_len, int cha)
{
	FILE *fp;
	fp = fopen(filename,"r");
	max_line_len = MAX_BUFFER;
	line = Malloc(char,max_line_len);

	char *endptr,*idx,*val, *label;
	int row = 0;
	int col = 0;

	for(uint i=0;i<prob_len;i++)
	{
		readline(fp);
		col = 0;
		label = strtok(line," \t\n");

		if(cha) h_Train[ (nFeats - 1)*prob_len + row] = (float)strtod(label,&endptr);
		else h_Test[row*nFeats + nFeats - 1] = (float)strtod(label,&endptr);

		while(1)
		{
			idx = strtok(NULL, ":");
			val = strtok(NULL, " \t");
			if(val == NULL)	break;

			int tmpIndex = (int) strtol(idx,&endptr,10);

			if((col+1) == tmpIndex)
			{
				if(cha) h_Train[col*prob_len + row] = (float)strtod(val,&endptr);
				else h_Test[row*nFeats + col] = (float)strtod(val,&endptr);
			}
			else if((col+1) < tmpIndex)
			{
				int tmpii = tmpIndex - (col + 1);
				for(int irr=0; irr<tmpii; irr++)
				{
					if(cha) h_Train[col*prob_len + row] = 0.0;
					else h_Test[row*nFeats + col] = 0.0;
					col++;
				}
				if(cha) h_Train[col*prob_len + row] = (float)strtod(val,&endptr);
				else h_Test[row*nFeats + col] = (float)strtod(val,&endptr);
			}
			col++;
		}
		row++;
	}
	fclose(fp);
	free(line);
	debug("problem length: %d, row/col: %d/%d, feature number: %d", prob_len, row, col, nFeats);
}
